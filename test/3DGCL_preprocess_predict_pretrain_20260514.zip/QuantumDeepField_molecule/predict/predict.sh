#!/usr/bin/env bash

# Dataset, model, and hyperparameter settings used in pre-training.
dataset_trained=QM9under7atoms_homolumo_eV
basis_set=6-31G
radius=0.75
grid_interval=0.3
dim=200
layer_functional=3
hidden_HK=200
layer_HK=3
operation=mean
batch_size=8
lr=1e-4
lr_decay=0.5
step_size=200
iteration=50
num_workers=0
setting=$dataset_trained--$basis_set--radius$radius--grid_interval$grid_interval--dim$dim--layer_functional$layer_functional--hidden_HK$hidden_HK--layer_HK$layer_HK--$operation--batch_size$batch_size--lr$lr--lr_decay$lr_decay--step_size$step_size--iteration$iteration

# Dataset for prediction.
dataset_predict=yourdataset_property_unit  # Extrapolation.

# Optional Rust toggles. Defaults preserve the original behaviour
# (npy loader + Python LCAO helpers). Override via env vars:
#   PREDICT_LOADER=shard PREDICT_PAD_IMPL=rust-pad-only ./predict.sh
loader_arg=()
pad_impl_arg=()
if [ -n "${PREDICT_LOADER}" ]; then
    loader_arg=(--loader "${PREDICT_LOADER}")
fi
if [ -n "${PREDICT_PAD_IMPL}" ]; then
    pad_impl_arg=(--pad-impl "${PREDICT_PAD_IMPL}")
fi

python predict.py $dataset_trained $basis_set $radius $grid_interval $dim $layer_functional $hidden_HK $layer_HK $operation $batch_size $lr $lr_decay $step_size $iteration $setting $num_workers $dataset_predict "${loader_arg[@]}" "${pad_impl_arg[@]}"
